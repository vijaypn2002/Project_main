from decimal import Decimal
from django.db import transaction
from django.db.models import F
from rest_framework import status
from rest_framework.response import Response
from rest_framework.views import APIView
from rest_framework.permissions import IsAuthenticated
from rest_framework_simplejwt.authentication import JWTAuthentication
from drf_spectacular.utils import extend_schema

from catalog.models import ProductVariant, Inventory
from .models import Order, OrderItem, Address, ReturnRequest
from .serializers import (
    CheckoutSerializer, OrderOutSerializer, OrderItemOutSerializer,
    ReturnRequestInSerializer, ReturnRequestOutSerializer
)
from orders.pricing import price_cart, _to_decimal, _round2
from cart.views import _get_or_create_cart


def _serialize_order(order: Order):
    items_qs = order.items.all()
    items = []
    for it in items_qs:
        items.append({
            "sku": it.sku,
            "name": it.name,
            "attributes": it.attributes or {},
            "price": it.price,
            "qty": it.qty,
            "line_total": it.line_total,
        })
    return {
        "id": order.id,
        "status": order.status,
        "subtotal": order.subtotal,
        "total": order.total,
        "items": items,
    }


class CheckoutView(APIView):
    authentication_classes = []
    permission_classes = []
    serializer_class = CheckoutSerializer

    @extend_schema(request=CheckoutSerializer, responses={201: OrderOutSerializer})
    def post(self, request):
        ser = CheckoutSerializer(data=request.data)
        ser.is_valid(raise_exception=True)

        cart = _get_or_create_cart(request)
        if not cart.items.exists():
            return Response({"detail": "Cart is empty."}, status=400)

        # Build variant map
        variant_ids = list(cart.items.values_list("variant_id", flat=True))
        variants = (
            ProductVariant.objects
            .select_related("product")
            .prefetch_related("inventory")
            .filter(id__in=variant_ids)
        )
        vmap = {v.id: v for v in variants}

        # Pre-validate against stock and backorder policy
        for ci in cart.items.all():
            v = vmap.get(ci.variant_id)
            if not v:
                return Response({"detail": f"Variant {ci.variant_id} not found."}, status=400)
            inv = getattr(v, "inventory", None)
            stock = getattr(inv, "qty_available", 0)
            backorder = getattr(inv, "backorder_policy", "block")
            if backorder != "allow" and ci.qty > stock:
                return Response({"detail": f"Insufficient stock for {v.sku}. Available: {stock}."}, status=400)

        totals = price_cart(cart)

        with transaction.atomic():
            # Lock inventory rows we’ll touch to avoid races
            inv_qs = (
                Inventory.objects
                .select_for_update()
                .filter(variant_id__in=variant_ids)
            )
            inv_map = {inv.variant_id: inv for inv in inv_qs}

            # Final guard before decrement (someone else might have purchased just now)
            for ci in cart.items.all():
                inv = inv_map.get(ci.variant_id)
                if inv and inv.backorder_policy != "allow" and ci.qty > inv.qty_available:
                    return Response({"detail": f"Insufficient stock for item {ci.variant_id}."}, status=409)

            addr = Address.objects.create(**ser.validated_data["shipping_address"])
            order = Order.objects.create(
                email=ser.validated_data["email"],
                shipping_address=addr,
                subtotal=_round2(totals["subtotal"] - totals["discount_total"]),
                total=totals["grand_total"],
            )

            # Write items + decrement stock
            for it in cart.items.select_related("variant", "variant__product"):
                v = vmap[it.variant_id]
                unit_price = _to_decimal(it.price_at_add or v.price_sale or v.price_mrp)
                line_total = _round2(unit_price * it.qty)

                OrderItem.objects.create(
                    order=order,
                    variant_id=v.id,
                    sku=v.sku,
                    name=v.product.name,
                    attributes=it.attributes_snapshot or {},
                    price=unit_price,
                    qty=it.qty,
                    line_total=line_total,
                )

                inv = inv_map.get(v.id)
                if inv and inv.backorder_policy != "allow":
                    # decrement and keep non-negative
                    if it.qty > inv.qty_available:
                        return Response({"detail": f"Race detected for {v.sku}; try again."}, status=409)
                    inv.qty_available = inv.qty_available - it.qty
                    inv.save(update_fields=["qty_available"])

            # Clear cart
            cart.items.all().delete()
            cart.applied_coupon = None
            cart.save(update_fields=["applied_coupon"])

        out = _serialize_order(order)
        return Response(out, status=201)


class OrderListView(APIView):
    authentication_classes = []
    permission_classes = []

    @extend_schema(responses={200: OrderOutSerializer(many=True)})
    def get(self, request):
        email = request.query_params.get("email")
        if not email:
            return Response({"detail": "email query param is required"}, status=400)
        orders = Order.objects.filter(email=email).order_by("-id")
        data = [_serialize_order(o) for o in orders]
        return Response(data, status=200)


class OrderDetailView(APIView):
    authentication_classes = []
    permission_classes = []

    @extend_schema(responses={200: OrderOutSerializer})
    def get(self, request, pk: int):
        email = request.query_params.get("email")
        if not email:
            return Response({"detail": "email query param is required"}, status=400)
        try:
            order = Order.objects.get(pk=pk, email=email)
        except Order.DoesNotExist:
            return Response({"detail": "Order not found"}, status=404)
        return Response(_serialize_order(order), status=200)


class MyOrdersView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    @extend_schema(responses={200: OrderOutSerializer(many=True)})
    def get(self, request):
        orders = Order.objects.filter(email=request.user.email).order_by("-id")
        data = [_serialize_order(o) for o in orders]
        return Response(data, status=200)


class MyOrderDetailView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    @extend_schema(responses={200: OrderOutSerializer})
    def get(self, request, pk: int):
        try:
            order = Order.objects.get(pk=pk, email=request.user.email)
        except Order.DoesNotExist:
            return Response({"detail": "Not found"}, status=404)
        return Response(_serialize_order(order), status=200)


# ---------- Returns (RMA) ----------
class ReturnRequestView(APIView):
    authentication_classes = [JWTAuthentication]
    permission_classes = [IsAuthenticated]

    @extend_schema(request=ReturnRequestInSerializer, responses={201: ReturnRequestOutSerializer})
    def post(self, request, pk: int):
        rser = ReturnRequestInSerializer(data=request.data)
        rser.is_valid(raise_exception=True)
        try:
            order = Order.objects.get(pk=pk, email=request.user.email)
            item = order.items.get(pk=rser.validated_data["order_item_id"])
        except (Order.DoesNotExist, OrderItem.DoesNotExist):
            return Response({"detail": "Order/Item not found"}, status=404)
        if rser.validated_data["qty"] > item.qty:
            return Response({"detail": "Qty exceeds purchased qty"}, status=400)
        rr = ReturnRequest.objects.create(
            order_item=item,
            qty=rser.validated_data["qty"],
            reason=rser.validated_data.get("reason", "")
        )
        out = ReturnRequestOutSerializer(rr).data
        return Response(out, status=201)

    @extend_schema(responses={200: ReturnRequestOutSerializer(many=True)})
    def get(self, request, pk: int):
        try:
            order = Order.objects.get(pk=pk, email=request.user.email)
        except Order.DoesNotExist:
            return Response({"detail": "Order not found"}, status=404)
        q = ReturnRequest.objects.filter(order_item__order=order).order_by("-id")
        data = ReturnRequestOutSerializer(q, many=True).data
        return Response(data, status=200)
