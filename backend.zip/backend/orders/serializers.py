from rest_framework import serializers


class AddressInputSerializer(serializers.Serializer):
    full_name = serializers.CharField()
    phone = serializers.CharField()
    line1 = serializers.CharField()
    line2 = serializers.CharField(required=False, allow_blank=True)
    city = serializers.CharField()
    state = serializers.CharField()
    postal_code = serializers.CharField()
    country = serializers.CharField(max_length=2, default="IN")


class CheckoutSerializer(serializers.Serializer):
    email = serializers.EmailField()
    shipping_address = AddressInputSerializer()
    shipping_method_id = serializers.IntegerField(required=False)
    coupon_code = serializers.CharField(required=False, allow_blank=True)


class OrderItemOutSerializer(serializers.Serializer):
    sku = serializers.CharField()
    name = serializers.CharField()
    attributes = serializers.JSONField()
    price = serializers.DecimalField(max_digits=10, decimal_places=2)
    qty = serializers.IntegerField()
    line_total = serializers.DecimalField(max_digits=10, decimal_places=2)


class OrderOutSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    status = serializers.CharField()
    subtotal = serializers.DecimalField(max_digits=10, decimal_places=2)
    total = serializers.DecimalField(max_digits=10, decimal_places=2)
    items = OrderItemOutSerializer(many=True)


class ReturnRequestInSerializer(serializers.Serializer):
    order_item_id = serializers.IntegerField()
    qty = serializers.IntegerField(min_value=1)
    reason = serializers.CharField(required=False, allow_blank=True)


class ReturnRequestOutSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    # NOTE: Remove source=... (it caused schema crash). Django exposes FK id as <field>_id.
    order_item_id = serializers.IntegerField()
    qty = serializers.IntegerField()
    status = serializers.CharField()
    reason = serializers.CharField()
