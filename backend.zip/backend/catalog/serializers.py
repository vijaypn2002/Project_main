from typing import Optional
from rest_framework import serializers
from drf_spectacular.utils import extend_schema_field

from .models import Category, Product, ProductVariant, Inventory, ProductImage


class CategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Category
        fields = ["id", "name", "slug", "parent"]


class InventorySerializer(serializers.ModelSerializer):
    class Meta:
        model = Inventory
        fields = ["qty_available", "backorder_policy"]


class ProductImageSerializer(serializers.ModelSerializer):
    class Meta:
        model = ProductImage
        fields = ["id", "image", "alt_text", "is_primary"]


class ProductVariantSerializer(serializers.ModelSerializer):
    inventory = InventorySerializer(read_only=True)

    class Meta:
        model = ProductVariant
        fields = ["id", "sku", "attributes", "price_mrp", "price_sale", "weight", "inventory"]


class ProductListSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)
    min_price = serializers.DecimalField(max_digits=10, decimal_places=2, read_only=True)
    primary_image = serializers.SerializerMethodField()

    class Meta:
        model = Product
        fields = ["id", "name", "slug", "brand", "status", "category", "min_price", "primary_image"]

    @extend_schema_field(ProductImageSerializer)
    def get_primary_image(self, obj) -> Optional[dict]:
        """
        If the view prefetches/annotates `_primary_image`, use it; otherwise
        fall back to the first image marked as primary.
        """
        img = getattr(obj, "_primary_image", None) or obj.images.filter(is_primary=True).first()
        return ProductImageSerializer(img).data if img else None


class ProductDetailSerializer(serializers.ModelSerializer):
    category = CategorySerializer(read_only=True)
    variants = ProductVariantSerializer(many=True, read_only=True)
    images = ProductImageSerializer(many=True, read_only=True)

    class Meta:
        model = Product
        fields = ["id", "name", "slug", "description", "brand", "status", "category", "variants", "images"]
