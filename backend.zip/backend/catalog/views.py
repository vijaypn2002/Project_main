from django.db.models import Min, Prefetch
from django.db.models.functions import Coalesce
from django_filters import rest_framework as filters
from rest_framework import viewsets
from rest_framework.decorators import action
from rest_framework.response import Response

from .models import Category, Product, ProductVariant, ProductImage
from .serializers import (
    CategorySerializer,
    ProductListSerializer,
    ProductDetailSerializer,
)


class ProductFilter(filters.FilterSet):
    # Use annotated min_price (sale if present else mrp)
    price_min = filters.NumberFilter(method="filter_price_min")
    price_max = filters.NumberFilter(method="filter_price_max")
    category = filters.CharFilter(field_name="category__slug", lookup_expr="iexact")
    brand = filters.CharFilter(field_name="brand", lookup_expr="icontains")

    class Meta:
        model = Product
        fields = ["category", "brand"]

    def filter_price_min(self, qs, name, value):
        return qs.filter(min_price__gte=value)

    def filter_price_max(self, qs, name, value):
        return qs.filter(min_price__lte=value)


class CategoryViewSet(viewsets.ReadOnlyModelViewSet):
    queryset = Category.objects.all().order_by("name")
    serializer_class = CategorySerializer
    lookup_field = "slug"


class ProductViewSet(viewsets.ReadOnlyModelViewSet):
    lookup_field = "slug"
    filterset_class = ProductFilter
    search_fields = ["name", "brand", "description"]
    ordering_fields = ["name", "id", "min_price"]

    def get_queryset(self):
        """
        Annotate each product with min_price = min(variant.price_sale or variant.price_mrp),
        prefetch primary image, and avoid duplicate rows.
        """
        variant_prices = Coalesce(Min("variants__price_sale"), Min("variants__price_mrp"))
        primary_image_qs = ProductImage.objects.filter(is_primary=True).order_by("id")

        return (
            Product.objects.select_related("category")
            .prefetch_related(
                # Ensure detail page is still efficient
                Prefetch("variants", queryset=ProductVariant.objects.select_related("inventory")),
                Prefetch("images", queryset=ProductImage.objects.order_by("sort", "id")),
                Prefetch("images", queryset=primary_image_qs, to_attr="_primary_images"),
            )
            .annotate(min_price=variant_prices)
            .distinct()
        )

    def get_serializer_class(self):
        return ProductDetailSerializer if self.action == "retrieve" else ProductListSerializer

    @action(detail=False, methods=["get"])
    def trending(self, request):
        # Simple placeholder: latest 8 active products. Replace with analytics later.
        qs = (
            self.get_queryset()
            .filter(status=Product.Status.ACTIVE)
            .order_by("-id")[:8]
        )
        # Attach a single primary image object to each product for the list serializer
        for p in qs:
            p._primary_image = (p._primary_images[0] if getattr(p, "_primary_images", None) else None)
        serializer = ProductListSerializer(qs, many=True, context={"request": request})
        return Response(serializer.data)
