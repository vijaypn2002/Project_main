from django.contrib.auth.models import User
from rest_framework import generics, permissions, viewsets
from .serializers import RegisterSerializer, UserSerializer, AddressSerializer
from .models import Address

class RegisterView(generics.CreateAPIView):
    queryset = User.objects.all()
    permission_classes = [permissions.AllowAny]
    serializer_class = RegisterSerializer

class MeView(generics.RetrieveUpdateAPIView):
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]
    def get_object(self):
        return self.request.user

class AddressViewSet(viewsets.ModelViewSet):
    serializer_class = AddressSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        return Address.objects.filter(user=self.request.user)

    def perform_create(self, serializer):
        obj = serializer.save(user=self.request.user)
        if obj.is_default:
            Address.objects.filter(user=self.request.user).exclude(id=obj.id).update(is_default=False)
