from django.contrib import admin
from .models import Address

@admin.register(Address)
class AddressAdmin(admin.ModelAdmin):
    list_display = ("user", "full_name", "city", "state", "is_default", "created_at")
    list_filter = ("is_default", "state")
    search_fields = ("full_name", "phone", "line1", "city", "postal_code")
