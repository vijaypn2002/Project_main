# (Cart applies coupons via cart.views.ApplyCouponView)
# Keep this app simple for now; admin handles creation.
