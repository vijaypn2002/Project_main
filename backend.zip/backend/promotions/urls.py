# Not required right now; coupon is applied via /cart/apply-coupon/
urlpatterns = []
