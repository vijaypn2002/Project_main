from django.contrib import admin
from .models import ShippingMethod, Shipment

@admin.register(ShippingMethod)
class ShippingMethodAdmin(admin.ModelAdmin):
    list_display = ("id","name","code","rate_type","base_rate","per_kg","free_over","is_active")
    search_fields = ("name","code")
    list_filter = ("is_active","rate_type")

@admin.register(Shipment)
class ShipmentAdmin(admin.ModelAdmin):
    list_display = ("id","order","method","status","tracking_no","created_at")
    search_fields = ("tracking_no",)
    list_filter = ("status","method")
    date_hierarchy = "created_at"
