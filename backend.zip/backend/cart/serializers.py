from rest_framework import serializers
from catalog.models import ProductVariant
from .models import Cart, CartItem


class CartItemCreateSerializer(serializers.Serializer):
    variant_id = serializers.IntegerField()
    qty = serializers.IntegerField(min_value=1)

    def validate(self, data):
        variant_id = data["variant_id"]
        qty = data["qty"]

        try:
            variant = ProductVariant.objects.select_related("inventory", "product").get(pk=variant_id)
        except ProductVariant.DoesNotExist:
            raise serializers.ValidationError({"variant_id": "Variant not found"})

        # Respect backorder policy server-side
        inv = getattr(variant, "inventory", None)
        stock = getattr(inv, "qty_available", None)
        backorder_policy = getattr(inv, "backorder_policy", "block")
        if backorder_policy != "allow" and stock is not None and stock < 1:
            raise serializers.ValidationError({"qty": "Out of stock"})
        if backorder_policy != "allow" and stock is not None and qty > stock:
            data["qty"] = int(stock)

        data["variant"] = variant  # pass through for view
        return data


class CartItemUpdateSerializer(serializers.Serializer):
    qty = serializers.IntegerField(min_value=1)


class CartItemOutSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    variant_id = serializers.IntegerField(source="variant.id")
    sku = serializers.CharField(source="variant.sku")
    name = serializers.CharField(source="variant.product.name")
    attributes = serializers.JSONField(source="attributes_snapshot")
    price = serializers.DecimalField(source="price_at_add", max_digits=10, decimal_places=2)
    qty = serializers.IntegerField()


class CartOutSerializer(serializers.Serializer):
    items = CartItemOutSerializer(many=True)
    subtotal = serializers.DecimalField(max_digits=10, decimal_places=2)
    discount_total = serializers.DecimalField(max_digits=10, decimal_places=2)
    tax_total = serializers.DecimalField(max_digits=10, decimal_places=2)
    shipping_total = serializers.DecimalField(max_digits=10, decimal_places=2)
    grand_total = serializers.DecimalField(max_digits=10, decimal_places=2)
    coupon = serializers.CharField(allow_null=True, required=False)
