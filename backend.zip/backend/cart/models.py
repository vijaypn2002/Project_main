from django.conf import settings
from django.db import models, transaction
from django.utils import timezone
from django.core.exceptions import ValidationError
from catalog.models import ProductVariant, Inventory
from promotions.models import Coupon

User = settings.AUTH_USER_MODEL


class Cart(models.Model):
    user = models.ForeignKey(
        User, null=True, blank=True, on_delete=models.CASCADE, related_name="carts"
    )
    session_id = models.CharField(max_length=64, blank=True, db_index=True)
    applied_coupon = models.ForeignKey(Coupon, null=True, blank=True, on_delete=models.SET_NULL)
    created_at = models.DateTimeField(default=timezone.now)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        indexes = [
            models.Index(fields=["session_id"]),
            models.Index(fields=["updated_at"]),
        ]

    def __str__(self):
        who = self.user or self.session_id or "guest"
        return f"Cart({who})"

    @transaction.atomic
    def merge_from(self, other: "Cart"):
        """Merge another cart's items into self (prefers larger qty). Atomic to avoid races."""
        if not other or other.id == self.id:
            return
        # Lock other items for update while merging
        other_items = (
            CartItem.objects.select_for_update()
            .filter(cart=other)
            .select_related("variant", "variant__inventory")
        )
        mine_map = {ci.variant_id: ci for ci in self.items.select_for_update()}
        to_create = []
        for oi in other_items:
            if oi.variant_id in mine_map:
                mi = mine_map[oi.variant_id]
                mi.qty = max(mi.qty, oi.qty)
                mi.full_clean()
                mi.save(update_fields=["qty"])
            else:
                to_create.append(
                    CartItem(
                        cart=self,
                        variant=oi.variant,
                        qty=oi.qty,
                        price_at_add=oi.price_at_add,
                        attributes_snapshot=oi.attributes_snapshot,
                    )
                )
        if to_create:
            CartItem.objects.bulk_create(to_create, ignore_conflicts=True)

        if other.applied_coupon and not self.applied_coupon:
            self.applied_coupon = other.applied_coupon
        self.save(update_fields=["applied_coupon", "updated_at"])
        other.delete()


class CartItem(models.Model):
    cart = models.ForeignKey(Cart, related_name="items", on_delete=models.CASCADE)
    variant = models.ForeignKey(ProductVariant, on_delete=models.PROTECT, related_name="+")
    qty = models.PositiveIntegerField(default=1)
    price_at_add = models.DecimalField(max_digits=10, decimal_places=2)
    attributes_snapshot = models.JSONField(default=dict, blank=True)

    class Meta:
        constraints = [
            models.UniqueConstraint(
                fields=["cart", "variant"], name="uq_cart_variant"
            )
        ]
        indexes = [
            models.Index(fields=["cart", "variant"]),
        ]

    def __str__(self):
        return f"{self.variant.sku} x {self.qty}"

    def _cap_qty_against_stock(self) -> int:
        inv: Inventory | None = getattr(self.variant, "inventory", None)
        stock = getattr(inv, "qty_available", None)
        backorder_policy = getattr(inv, "backorder_policy", "block")
        if stock is None:
            return self.qty  # no inventory record -> don't cap here
        if backorder_policy == "allow":
            return self.qty
        # block backorder: cap to stock (may be zero)
        return min(self.qty, max(int(stock), 0))

    def clean(self):
        # Normalize qty
        if self.qty is None or self.qty < 1:
            self.qty = 1

        # Price/attributes defaults
        if not self.price_at_add:
            self.price_at_add = self.variant.price_sale or self.variant.price_mrp
        if not self.attributes_snapshot:
            self.attributes_snapshot = getattr(self.variant, "attributes", {}) or {}

        # Stock policy
        capped = self._cap_qty_against_stock()
        if capped < 1:
            # No stock and no backorders; tell the client
            raise ValidationError({"qty": "This item is out of stock."})
        # Keep the *requested* qty if backorders allowed, otherwise cap
        if capped != self.qty:
            self.qty = capped

    def save(self, *args, **kwargs):
        self.full_clean()
        super().save(*args, **kwargs)
