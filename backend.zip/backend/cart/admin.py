from django.contrib import admin
from .models import Cart, CartItem


class ItemInline(admin.TabularInline):
    model = CartItem
    extra = 0
    readonly_fields = ("price_at_add", "attributes_snapshot")


@admin.register(Cart)
class CartAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "session_id", "applied_coupon", "item_count", "updated_at")
    search_fields = ("session_id",)
    inlines = [ItemInline]

    def item_count(self, obj: Cart) -> int:
        return obj.items.count()
    item_count.short_description = "Items"
